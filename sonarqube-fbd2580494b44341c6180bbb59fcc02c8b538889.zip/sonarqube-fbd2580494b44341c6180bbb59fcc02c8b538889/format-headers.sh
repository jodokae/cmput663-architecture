#!/bin/bash
# Set correct copyright headers

mvn license:format -Pit
