Order of modules during build would look as following :
parent
module_a
module_b
root
