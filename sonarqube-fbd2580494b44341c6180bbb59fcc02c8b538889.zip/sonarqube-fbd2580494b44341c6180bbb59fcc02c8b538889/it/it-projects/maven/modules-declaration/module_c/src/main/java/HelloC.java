public class HelloC {
}
