package org.sonar.tests;

public class Hello {
	public static String s=null;
	
	public String toString() {
		while(true) 
		  s="hello";	
	}
}