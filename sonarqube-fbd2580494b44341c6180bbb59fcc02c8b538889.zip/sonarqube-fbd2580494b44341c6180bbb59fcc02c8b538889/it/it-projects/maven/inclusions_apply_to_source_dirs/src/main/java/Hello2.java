public class Hello2 {
  public String hello() {
    return "hello";
  }
}
