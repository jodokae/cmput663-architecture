Note that if you expect "test_execution_time" greater than zero, then you should guarantee execution time at least in 1 second.
So use Thread.sleep in order to have stable test.
