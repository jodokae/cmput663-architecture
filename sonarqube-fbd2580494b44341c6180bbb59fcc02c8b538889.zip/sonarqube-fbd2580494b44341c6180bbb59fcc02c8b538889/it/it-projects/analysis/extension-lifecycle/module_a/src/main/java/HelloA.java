public class HelloA {
	private int i;
	private HelloA() {
		
	}
	
	public void hello() {
		System.out.println("hello" + " world");
	}
}