public class HelloB {
	private int i;
	private HelloB() {
		
	}
	
	public void hello() {
		System.out.println("hello" + " world");
	}
}