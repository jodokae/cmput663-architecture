public class HelloJava {
	private int i;
	private HelloJava() {
		
	}
	
	public void hello() {
		System.out.println("hello" + " java");
	}
}