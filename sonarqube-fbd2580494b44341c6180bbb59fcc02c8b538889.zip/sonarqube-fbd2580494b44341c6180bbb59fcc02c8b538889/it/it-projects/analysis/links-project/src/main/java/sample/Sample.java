package sample;

public class Sample {
	
	public Sample(int i) {
		int j = i++;
	}
	
	private String myMethod() {
		return "hello";
	}
}
