package com.sonar.it.samples.modules.a2;

public class HelloA2 {
	private int i;
	private HelloA2() {
		
	}
	
	public void hello() {
		System.out.println("hello" + " world");
	}
}