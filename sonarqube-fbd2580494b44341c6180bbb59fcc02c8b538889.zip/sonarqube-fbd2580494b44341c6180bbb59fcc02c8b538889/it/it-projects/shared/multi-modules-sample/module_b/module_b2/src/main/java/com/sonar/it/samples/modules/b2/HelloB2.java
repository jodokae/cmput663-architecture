package com.sonar.it.samples.modules.b2;

public class HelloB2 {
	private int i;
	private HelloB2() {
		
	}
	
	public void hello() {
		System.out.println("hello" + " world");
	}
}