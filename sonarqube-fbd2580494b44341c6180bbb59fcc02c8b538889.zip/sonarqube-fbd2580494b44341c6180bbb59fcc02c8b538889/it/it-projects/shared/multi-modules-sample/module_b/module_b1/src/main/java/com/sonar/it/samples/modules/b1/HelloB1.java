package com.sonar.it.samples.modules.b1;

public class HelloB1 {
	private int i;
	private HelloB1() {
		
	}
	
	public void hello() {
		System.out.println("hello" + " world");
	}
}