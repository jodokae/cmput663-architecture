package foo;

public class Simplest2 {

	public static void foo() {}

}
