package foo;

public class Simplest3 {

}
