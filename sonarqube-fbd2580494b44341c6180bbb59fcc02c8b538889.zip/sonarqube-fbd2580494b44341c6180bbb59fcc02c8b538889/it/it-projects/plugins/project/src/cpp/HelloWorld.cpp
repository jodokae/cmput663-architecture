using namespace std;

int main ()
{
   // comment
   cout << "Hello World!";
   return 0;
}
