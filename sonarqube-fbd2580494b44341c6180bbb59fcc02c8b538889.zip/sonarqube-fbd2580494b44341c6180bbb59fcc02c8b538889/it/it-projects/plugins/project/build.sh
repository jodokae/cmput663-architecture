#!/bin/sh

mvn package
