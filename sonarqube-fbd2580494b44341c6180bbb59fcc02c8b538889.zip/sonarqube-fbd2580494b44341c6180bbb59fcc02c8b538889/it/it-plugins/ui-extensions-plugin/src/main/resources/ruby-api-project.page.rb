<h1>Ruby API Project</h1>

<p>Project name is: <span id="ruby-api-project"><%= @project.name -%></span></p>
