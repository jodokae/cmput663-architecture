### License

Copyright 2008-2016 SonarSource.

Licensed under the [GNU Lesser General Public License, Version 3.0](http://www.gnu.org/licenses/lgpl.txt)

### Build status

[![Build Status](https://travis-ci.org/SonarSource/sonarqube.svg?branch=master)](https://travis-ci.org/SonarSource/sonarqube)

### Links

Project website: http://www.sonarqube.org/

Documentation: http://docs.sonarqube.org/display/SONAR

Issue tracking: http://jira.sonarsource.com/browse/SONAR

How to contribute: http://www.sonarqube.org/development/
